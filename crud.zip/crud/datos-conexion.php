<?php
$servidor="localhost";
$usuario="root";
$clave="";
$baseDatos="iaw21-22";
$puerto=3306;
?>