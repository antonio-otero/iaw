<?php 

$servidorBD="localhost";
$usuarioBD="root";
$claveBD="";
$baseDatos="iaw21-22";
$puerto=3306; //porto por defecto de msql

?>